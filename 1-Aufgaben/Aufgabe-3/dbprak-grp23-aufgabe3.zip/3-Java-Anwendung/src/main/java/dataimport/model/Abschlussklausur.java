package dataimport.model;

public class Abschlussklausur extends Klausur {
    Integer klausurId;
}
