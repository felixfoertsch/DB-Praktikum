package dataimport.model;

public class Spezialvorlesung extends Veranstaltung {
    Integer veranstaltungId;
}
