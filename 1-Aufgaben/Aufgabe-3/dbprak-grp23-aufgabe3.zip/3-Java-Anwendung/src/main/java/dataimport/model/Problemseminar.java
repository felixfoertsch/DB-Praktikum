package dataimport.model;

public class Problemseminar extends Seminar {
    Integer seminarId;
}
