package dataimport.model;

public class Oberseminar extends Seminar {
    Integer seminarId;
}
