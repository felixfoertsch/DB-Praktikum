package dataimport.model;

public class Wiederholungsklausur extends Abschlussklausur {
    Integer klausurId;
}
