package model;

public class Abschlussklausur extends Klausur {
    Integer klausurId;
}
