package model;

public class Spezialvorlesung extends Veranstaltung {
    Integer veranstaltungId;
}
