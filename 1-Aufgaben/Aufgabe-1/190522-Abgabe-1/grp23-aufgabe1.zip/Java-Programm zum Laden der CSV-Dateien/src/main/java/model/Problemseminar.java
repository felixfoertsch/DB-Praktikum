package model;

public class Problemseminar extends Seminar {
    Integer seminarId;
}
